from django.shortcuts import render,render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from django.template import Template,Context
from django.template.loader import get_template
#import pymysql as MySQLdb
#from django.shortcuts import render_to_response
from django.template import RequestContext
from register.models import registeredclass,feeinfo
from django.core.urlresolvers import reverse

#these are import to get default authentication
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required   #login_required used to limiting access to login user

#User models store the username,password or emailid
from django.contrib.auth.models import User


# Create your views here.
cur_user=registeredclass
def index(request):
	return render_to_response("index.html",context_instance=RequestContext(request))

def login_view(request):
	if not request.user.is_authenticated():
		return render_to_response("login.html",context_instance=RequestContext(request))
	else:
		username=request.user.username
		return HttpResponseRedirect(reverse('register:home',args=(username,)))
	
def register(request):
	#textnew=get_template('register.html')
	#return HttpResponse(textnew.render(Context()))
	return render_to_response("register.html", context_instance=RequestContext(request))
def home(request,username):
	if request.user.is_authenticated():
		username=request.user.registeredclass.name
		books=request.user.registeredclass.books
		return render(request,"home.html",{"username":username,"books":books})
	else:
		return	render_to_response("page_except.html",context_instance=RequestContext(request)) 
def registered(request):

	photo=request.POST.get('photo','')
	name=request.POST.get('name','')
	dob=request.POST.get('dob','')
	fname=request.POST.get('fname','')
	email_id=request.POST.get('email','')
	pass1=request.POST.get('pass1','')
	rollno_v=request.POST.get('rollno','')
	phone=request.POST.get('phn','')
	branch_v=request.POST.get('branch','')
	address_v=request.POST.get('address','')
	pincode_v=request.POST.get('pincode','')
	#try:
	User.objects.create_user(rollno_v,email_id,pass1)
	userobj=User.objects.get(username=rollno_v)
	o=registeredclass					(user=userobj,name=name,branch=branch_v,mobile=phone,address=address_v,pincode=pincode_v,dob=dob,fathername=fname,photo=photo)
	o.save()	
	return render_to_response("registered.html", context_instance=RequestContext(request))
	#except (IntegrityError, register_registeredclass.rollno)
	#	return render_to_response("f.html", context_instance=RequestContext(request))


def logincheck(request):
	username=request.POST.get('roll','')
	password=request.POST.get('pass','')
	user=authenticate(username=username,password=password)
	if user is not None:
		if user.is_active:
			login(request,user)
			return HttpResponseRedirect(reverse('register:home',args=(username,)))		
		else:
			#return a diable account message
			return render(request,'login.html',{'error_message':'your account is dissable'})
	else :
		#return invalid user name or password
		return render(request,'login.html',{'error_message':'invalid username or password'})
def my_logout(request,username):
	logout(request)
	#redirect to success page
	return render_to_response("logout.html",context_instance=RequestContext(request))

def getfee(request,username):
	year=request.GET.get("year",'')
	semester=request.GET.get("semester",'')
	obj=feeinfo.objects.get(year=year)
	if semester=="even":
		fee=obj.even
	else:
		fee=obj.odd		
	return render_to_response("fee.html",{"year":year,"fee": fee})
