from django.conf.urls import patterns,include, url
from register.views import *
from django.views.generic import ListView
app_name='register'
urlpatterns = [
	url(r'^registration/$',index,name='index'),
	url(r'^login/$',login_view,name='my_login`'),
	url(r'^register/$', register,name='register'),
	url(r'^registered/$',registered,name='registered'),
	url(r'^login/check/$',logincheck,name='logincheck'),
	url(r'^home/(?P<username>[^/]+)/$',home,name='home'),
	url(r'^home/(?P<username>[^/]+)/logout/$',my_logout,name='my_logout'),
	url(r'^home/(?P<username>[^/]+)/getfee/$',getfee,name='getfee')
]
