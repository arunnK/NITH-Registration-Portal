from django.db import models
from django.contrib.auth.models import User
class registeredclass(models.Model):
	user=models.OneToOneField(User, on_delete=models.CASCADE,null=True)		#user name is rollno of student
	photo=models.ImageField()
	name=models.CharField(max_length=30)
	dob=models.CharField(max_length=15)
	fathername=models.CharField(max_length=30)
	#email=models.EmailField(unique=True)
	#password=models.CharField(max_length=10)
	
	mobile= models.IntegerField()
	branch=models.CharField(max_length=40)
	address=models.TextField()
	pincode=models.IntegerField()
	books=models.IntegerField(default=12)
	def __str__(self):
		return self.name

class feeinfo(models.Model):
	year=models.CharField(max_length=10)
	even=models.IntegerField()
	odd=models.IntegerField()
# Create your models here.
